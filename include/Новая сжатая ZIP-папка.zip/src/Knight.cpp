#include "Knight.h"

Knight::Knight(std::string color, int x, int y)
    : JumpingPiece(color, x, y) {
}

Knight::Knight(const Knight& other)
    : JumpingPiece(other) {
}

char Knight::getSymbol() const {
    return 'N';
}

void Knight::printInfo() const {
    ChessPiece::printInfo();
    std::cout << "Тип фигуры: Конь\n";
}
